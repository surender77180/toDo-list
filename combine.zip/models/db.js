const {MongoClient}= require("mongodb");
const url = "mongodb://localhost:27017";
const client = new MongoClient(url);

async function dbConnect(){
    const connection = await client.connect();
    const db = connection.db("newdb"); //database nam
    return db.collection("summerTraning"); //collection name
    // let res = await collection.find({}).toArray(); //data find
    // console.log(res);
}

module.exports = dbConnect;