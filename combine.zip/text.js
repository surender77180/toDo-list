console.log("hello surender");
setTimeout(() => {
    console.log("hello ankush");
}, 3000);

console.log("hello mohit");